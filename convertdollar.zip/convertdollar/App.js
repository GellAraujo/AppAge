import React, {useState} from 'react';
import { Text, View, StyleSheet, TextInput, TouchableOpacity } from 'react-native';

export default function App() {
  
    let [totalReal, setTotalReal] = useState ('');
    let [totalDollar, setTotalDollar] = useState ('');
    let [cotacao, setCotacao] = useState ('');

    function Converte (){
      totalDollar = parseFloat (totalReal) / cotacao;

      alert ("Total em Dollars: " + totalDollar.toFixed(2));

    } 
  return (
        <View style={styles.container}> 
		<Text style={styles.titulo}>Aplicativo Dollar</Text>

		<TextInput style={styles.campo} placeholder= "Digite o Valor em R$" keyboardType="numeric" 		
    onChangeText={(totalReal) => setTotalReal (totalReal)} />

    <TextInput style={styles.campo} placeholder= "Digite a Cotação do Dia" keyboardType="numeric" 		
    onChangeText={(cotacao) => setCotacao (cotacao)} /> 
	
		<TouchableOpacity style={styles.botao} 
		onPress={Converte}> 
		<Text style={styles.textoBotao}>Total Dollars</Text> 
		</TouchableOpacity> </View> ); } 
	
			const styles = StyleSheet.create({ 
			container: { 
			flex: 1, 
			backgroundColor: "#FFD700" 
			}, 
			titulo:{ 
			textAlign: 'center', 
			marginTop: 40,
			marginBottom: 40,
			fontSize: 30,
			color: "#FFF" 
			}, 
			campo:{ 
			textAlign: 'center',
			backgroundColor: "#FFF",
			borderRadius: 20,
			margin: 15,
 			padding: 5,
 			fontSize: 15, 
			}, 
			botao:{ 
			justifyContent: 'center', 
			alignItems: 'center', 
			margin: 15, 
			backgroundColor: "#F0F8FF", 
			padding: 5, 
			borderRadius: 20, 
			}, 
			textoBotao: { 
			fontSize: 20 
			},
	});