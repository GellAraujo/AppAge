import React, {useState} from 'react'; 
import { Text, View, StyleSheet, TextInput, TouchableOpacity } from 'react-native'; 
	export default function App() 
	{ 
	//Variaveis 
		var [C, setC] = useState(''); 
		var [F, setF] = useState(''); 
	
		function CaalcularTemperatura(){ 
	//F=(9*C+160)/5 
		F = (9 * parseFloat(C) + 160)/5; 
		alert("Temperatura em Fahrenheit: " + F);
	} 
	return ( 
		<View style={styles.container}> 
		<Text style={styles.titulo}>Aplicativo Temperatura</Text> 
		<TextInput style={styles.campo} placeholder= "Digite a Temperatura em °C" keyboardType="numeric" 		
    onChangeText={ (C) => setC(C) } /> 
	
		<TouchableOpacity style={styles.botao} 
		onPress={CaalcularTemperatura}> 
		<Text style={styles.textoBotao}>Calcular</Text> 
		</TouchableOpacity> </View> ); } 
	
			const styles = StyleSheet.create({ 
			container: { 
			flex: 1, 
			backgroundColor: "blue" 
			}, 
			titulo:{ 
			textAlign: 'center', 
			marginTop: 40,
			marginBottom: 40,
			fontSize: 30,
			color: "#FFF" 
			}, 
			campo:{ 
			textAlign: 'center',
			backgroundColor: "#FFF",
			borderRadius: 20,
			margin: 15,
 			padding: 5,
 			fontSize: 15, 
			}, 
			botao:{ 
			justifyContent: 'center', 
			alignItems: 'center', 
			margin: 15, 
			backgroundColor: "#F0F8FF", 
			padding: 5, 
			borderRadius: 20, 
			}, 
			textoBotao: { 
			fontSize: 20 
			},
	});